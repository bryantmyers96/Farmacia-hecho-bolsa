/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Clases;

import java.util.ArrayList;

/**
 *
 * @author thotstin
 */
public interface Sentencias {

    boolean insertar();

    ArrayList consulta();

    public boolean actualizar();

    public boolean eliminar();
}
